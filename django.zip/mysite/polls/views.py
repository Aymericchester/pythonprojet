from django.shortcuts import render

import pandas as pd
import matplotlib.pyplot as plt
import base64, urllib
import io
import geopandas as gpd

dtype = {
    'Identifiant de document': str,
    'Reference document': str,
    '1 Articles CGI': str,
    '2 Articles CGI': str,
    '3 Articles CGI': str,
    '4 Articles CGI': str,
    '5 Articles CGI': str,
    'No disposition': int,
    'Date mutation': str,
    'Nature mutation': str,
    'Valeur fonciere': float,
    'No voie': str,
    'B/T/Q': str,
    'Type de voie': str,
    'Code voie': str,
    'Voie': str,
    'Code postal': str,
    'Commune': str,
    'Code departement': str,
    'Code commune': str,
    'Prefixe de section': str,
    'Section': str,
    'No plan': str,
    'No Volume': str,
    '1er lot': str,
    'Surface Carrez du 1er lot': float,
    '2eme lot': str,
    'Surface Carrez du 2eme lot': float,
    '3eme lot': str,
    'Surface Carrez du 3eme lot': float,
    '4eme lot': str,
    'Surface Carrez du 4eme lot': float,
    '5eme lot': str,
    'Surface Carrez du 5eme lot': float,
    'Nombre de lots': int,
    'Code type local': str,
    'Type local': str,
    'Identifiant local': str,
    'Surface reelle bati': float,
    'Nombre pieces principales': float,
    'Nature culture': str,
    'Nature culture speciale': str,
    'Surface terrain': float
}

def index(request):
    plt.clf()
    df=pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt', sep='|', dtype=dtype)
    columns_to_drop = ['No disposition', 'B/T/Q', 'No plan', 'No Volume', '1er lot', 'Surface Carrez du 1er lot',
               '2eme lot', 'Surface Carrez du 2eme lot', '3eme lot', 'Surface Carrez du 3eme lot',
               '4eme lot', 'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot',
               'Nombre de lots', 'Identifiant local', 'Surface reelle bati', 'Nombre pieces principales',
               'Nature culture', 'Nature culture speciale', 'Surface terrain']
    df = df.drop(columns=columns_to_drop)

    # Convertir la colonne "Date mutation" en objet datetime
    df['Date mutation'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y')

    # Ajouter une colonne pour l'année de la mutation
    df['Année'] = df['Date mutation'].dt.year
    counts = df['Type local'].value_counts()
    plt.pie(counts.values, labels=counts.index, autopct='%1.1f%%')
    plt.title('Répartition des types de biens immobiliers vendus en 2020')
    plt.axis('equal')
    fig=plt.gcf()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template0.html', {'data': uri})

def index1(request): 
    plt.clf()
    if (request.GET['model']=="2022"):
        df=pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt', sep='|', dtype=dtype)
        columns_to_drop = ['No disposition', 'B/T/Q', 'No plan', 'No Volume', '1er lot', 'Surface Carrez du 1er lot',
                   '2eme lot', 'Surface Carrez du 2eme lot', '3eme lot', 'Surface Carrez du 3eme lot',
                   '4eme lot', 'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot',
                   'Nombre de lots', 'Identifiant local', 'Surface reelle bati', 'Nombre pieces principales',
                   'Nature culture', 'Nature culture speciale', 'Surface terrain']
        df = df.drop(columns=columns_to_drop)

        # Convertir la colonne "Date mutation" en objet datetime
        df['Date mutation'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y')

        # Ajouter une colonne pour l'année de la mutation
        df['Année'] = df['Date mutation'].dt.year
        counts = df['Type local'].value_counts()
        plt.pie(counts.values, labels=counts.index, autopct='%1.1f%%')
        plt.title('Répartition des types de biens immobiliers vendus en 2022')
        plt.axis('equal')
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df=pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt', sep='|', dtype=dtype)
        columns_to_drop = ['No disposition', 'B/T/Q', 'No plan', 'No Volume', '1er lot', 'Surface Carrez du 1er lot',
                   '2eme lot', 'Surface Carrez du 2eme lot', '3eme lot', 'Surface Carrez du 3eme lot',
                   '4eme lot', 'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot',
                   'Nombre de lots', 'Identifiant local', 'Surface reelle bati', 'Nombre pieces principales',
                   'Nature culture', 'Nature culture speciale', 'Surface terrain']
        df = df.drop(columns=columns_to_drop)

        # Convertir la colonne "Date mutation" en objet datetime
        df['Date mutation'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y')

        # Ajouter une colonne pour l'année de la mutation
        df['Année'] = df['Date mutation'].dt.year
        counts = df['Type local'].value_counts()
        plt.pie(counts.values, labels=counts.index, autopct='%1.1f%%')
        plt.title('Répartition des types de biens immobiliers vendus en 2021')
        plt.axis('equal')
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df=pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt', sep='|', dtype=dtype)
        columns_to_drop = ['No disposition', 'B/T/Q', 'No plan', 'No Volume', '1er lot', 'Surface Carrez du 1er lot',
                   '2eme lot', 'Surface Carrez du 2eme lot', '3eme lot', 'Surface Carrez du 3eme lot',
                   '4eme lot', 'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot',
                   'Nombre de lots', 'Identifiant local', 'Surface reelle bati', 'Nombre pieces principales',
                   'Nature culture', 'Nature culture speciale', 'Surface terrain']
        df = df.drop(columns=columns_to_drop)

        # Convertir la colonne "Date mutation" en objet datetime
        df['Date mutation'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y')

        # Ajouter une colonne pour l'année de la mutation
        df['Année'] = df['Date mutation'].dt.year
        counts = df['Type local'].value_counts()
        plt.pie(counts.values, labels=counts.index, autopct='%1.1f%%')
        plt.title('Répartition des types de biens immobiliers vendus en 2020')
        plt.axis('equal')
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df=pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt', sep='|', dtype=dtype)
        columns_to_drop = ['No disposition', 'B/T/Q', 'No plan', 'No Volume', '1er lot', 'Surface Carrez du 1er lot',
                   '2eme lot', 'Surface Carrez du 2eme lot', '3eme lot', 'Surface Carrez du 3eme lot',
                   '4eme lot', 'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot',
                   'Nombre de lots', 'Identifiant local', 'Surface reelle bati', 'Nombre pieces principales',
                   'Nature culture', 'Nature culture speciale', 'Surface terrain']
        df = df.drop(columns=columns_to_drop)

        # Convertir la colonne "Date mutation" en objet datetime
        df['Date mutation'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y')

        # Ajouter une colonne pour l'année de la mutation
        df['Année'] = df['Date mutation'].dt.year
        counts = df['Type local'].value_counts()
        plt.pie(counts.values, labels=counts.index, autopct='%1.1f%%')
        plt.title('Répartition des types de biens immobiliers vendus en 2019')
        plt.axis('equal')
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df=pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt', sep='|', dtype=dtype)
        columns_to_drop = ['No disposition', 'B/T/Q', 'No plan', 'No Volume', '1er lot', 'Surface Carrez du 1er lot',
                   '2eme lot', 'Surface Carrez du 2eme lot', '3eme lot', 'Surface Carrez du 3eme lot',
                   '4eme lot', 'Surface Carrez du 4eme lot', '5eme lot', 'Surface Carrez du 5eme lot',
                   'Nombre de lots', 'Identifiant local', 'Surface reelle bati', 'Nombre pieces principales',
                   'Nature culture', 'Nature culture speciale', 'Surface terrain']
        df = df.drop(columns=columns_to_drop)

        # Convertir la colonne "Date mutation" en objet datetime
        df['Date mutation'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y')

        # Ajouter une colonne pour l'année de la mutation
        df['Année'] = df['Date mutation'].dt.year
        counts = df['Type local'].value_counts()
        plt.pie(counts.values, labels=counts.index, autopct='%1.1f%%')
        plt.title('Répartition des types de biens immobiliers vendus en 2018')
        plt.axis('equal')
        fig=plt.gcf()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template0.html', {'data': uri})

def index2(request):
    plt.clf()
    df = pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt', sep='|', dtype=dtype)
    df = df[['Code departement', 'Valeur fonciere']]
    transactions_par_departement = df.groupby('Code departement')['Valeur fonciere'].count().reset_index()
    url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
    france = gpd.read_file(url)
    merged = france.merge(transactions_par_departement, left_on='code', right_on='Code departement')
    ax = merged.plot(column='Valeur fonciere', cmap='Reds', figsize=(10, 10), legend=True)
    ax.set_title("Nombre de transactions immobilières par département en 2022")  
    ax.set_axis_off()
    fig=plt.gcf()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template1.html', {'data': uri})

def index3(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt', sep='|', dtype=dtype)
        df = df[['Code departement', 'Valeur fonciere']]
        transactions_par_departement = df.groupby('Code departement')['Valeur fonciere'].count().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(transactions_par_departement, left_on='code', right_on='Code departement')
        ax = merged.plot(column='Valeur fonciere', cmap='Reds', figsize=(10, 10), legend=True)
        ax.set_title("Nombre de transactions immobilières par département en 2022")  
        ax.set_axis_off()
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df = pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt', sep='|', dtype=dtype)
        df = df[['Code departement', 'Valeur fonciere']]
        transactions_par_departement = df.groupby('Code departement')['Valeur fonciere'].count().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(transactions_par_departement, left_on='code', right_on='Code departement')
        ax = merged.plot(column='Valeur fonciere', cmap='Reds', figsize=(10, 10), legend=True)
        ax.set_title("Nombre de transactions immobilières par département en 2021")  
        ax.set_axis_off()
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt', sep='|', dtype=dtype)
        df = df[['Code departement', 'Valeur fonciere']]
        transactions_par_departement = df.groupby('Code departement')['Valeur fonciere'].count().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(transactions_par_departement, left_on='code', right_on='Code departement')
        ax = merged.plot(column='Valeur fonciere', cmap='Reds', figsize=(10, 10), legend=True)
        ax.set_title("Nombre de transactions immobilières par département en 2020")  
        ax.set_axis_off()
        fig=plt.gcf()
    
    if (request.GET['model']=="2019"):
        df = pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt', sep='|', dtype=dtype)
        df = df[['Code departement', 'Valeur fonciere']]
        transactions_par_departement = df.groupby('Code departement')['Valeur fonciere'].count().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(transactions_par_departement, left_on='code', right_on='Code departement')
        ax = merged.plot(column='Valeur fonciere', cmap='Reds', figsize=(10, 10), legend=True)
        ax.set_title("Nombre de transactions immobilières par département en 2019")  
        ax.set_axis_off()
        fig=plt.gcf()
    
    if (request.GET['model']=="2018"):
        df = pd.read_csv('C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt', sep='|', dtype=dtype)
        df = df[['Code departement', 'Valeur fonciere']]
        transactions_par_departement = df.groupby('Code departement')['Valeur fonciere'].count().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(transactions_par_departement, left_on='code', right_on='Code departement')
        ax = merged.plot(column='Valeur fonciere', cmap='Reds', figsize=(10, 10), legend=True)
        ax.set_title("Nombre de transactions immobilières par département en 2018")  
        ax.set_axis_off()
        fig=plt.gcf()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template1.html', {'data': uri})

def index4(request):
    plt.clf()
    data = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", sep='|', dtype=dtype)
    data["Type local"] = data["Type local"].astype(str)
    data = data[~data["Type local"].str.startswith(("COM", "CT"))]
    if not pd.api.types.is_numeric_dtype(data["Valeur fonciere"]):
        print("La colonne Valeur fonciere ne contient pas de données numériques.")
        return
    data_agg = data.groupby("Code departement")["Valeur fonciere"].sum().reset_index()
    departements = gpd.read_file("https://github.com/gregoiredavid/france-geojson/raw/master/departements.geojson")
    departements = departements.merge(data_agg, left_on="code", right_on="Code departement")
    fig, ax = plt.subplots(figsize=(10, 5))
    departements.plot(column="Valeur fonciere", cmap="YlGnBu", linewidth=0.8, edgecolor='0.8', ax=ax, legend=True)
    ax.axis('off')
    ax.set_title("Valeur fonciere par département en France en 2022 (en euros)", fontdict={'fontsize': '18', 'fontweight' : '3'})
    fig=plt.gcf()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template2.html', {'data': uri})



def index5(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        data = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", sep='|', dtype=dtype)
        data["Type local"] = data["Type local"].astype(str)
        data = data[~data["Type local"].str.startswith(("COM", "CT"))]
        if not pd.api.types.is_numeric_dtype(data["Valeur fonciere"]):
            print("La colonne Valeur fonciere ne contient pas de données numériques.")
            return
        data_agg = data.groupby("Code departement")["Valeur fonciere"].sum().reset_index()
        departements = gpd.read_file("https://github.com/gregoiredavid/france-geojson/raw/master/departements.geojson")
        departements = departements.merge(data_agg, left_on="code", right_on="Code departement")
        fig, ax = plt.subplots(figsize=(10, 5))
        departements.plot(column="Valeur fonciere", cmap="YlGnBu", linewidth=0.8, edgecolor='0.8', ax=ax, legend=True)
        ax.axis('off')
        ax.set_title("Valeur fonciere par département en France en 2022 (en euros)", fontdict={'fontsize': '18', 'fontweight' : '3'})
        fig=plt.gcf()
    
    if (request.GET['model']=="2021"):
        data = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", sep='|', dtype=dtype)
        data["Type local"] = data["Type local"].astype(str)
        data = data[~data["Type local"].str.startswith(("COM", "CT"))]
        if not pd.api.types.is_numeric_dtype(data["Valeur fonciere"]):
            print("La colonne Valeur fonciere ne contient pas de données numériques.")
            return
        data_agg = data.groupby("Code departement")["Valeur fonciere"].sum().reset_index()
        departements = gpd.read_file("https://github.com/gregoiredavid/france-geojson/raw/master/departements.geojson")
        departements = departements.merge(data_agg, left_on="code", right_on="Code departement")
        fig, ax = plt.subplots(figsize=(10, 5))
        departements.plot(column="Valeur fonciere", cmap="YlGnBu", linewidth=0.8, edgecolor='0.8', ax=ax, legend=True)
        ax.axis('off')
        ax.set_title("Valeur fonciere par département en France en 2021 (en euros)", fontdict={'fontsize': '18', 'fontweight' : '3'})
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        data = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", sep='|', dtype=dtype)
        data["Type local"] = data["Type local"].astype(str)
        data = data[~data["Type local"].str.startswith(("COM", "CT"))]
        if not pd.api.types.is_numeric_dtype(data["Valeur fonciere"]):
            print("La colonne Valeur fonciere ne contient pas de données numériques.")
            return
        data_agg = data.groupby("Code departement")["Valeur fonciere"].sum().reset_index()
        departements = gpd.read_file("https://github.com/gregoiredavid/france-geojson/raw/master/departements.geojson")
        departements = departements.merge(data_agg, left_on="code", right_on="Code departement")
        fig, ax = plt.subplots(figsize=(10, 5))
        departements.plot(column="Valeur fonciere", cmap="YlGnBu", linewidth=0.8, edgecolor='0.8', ax=ax, legend=True)
        ax.axis('off')
        ax.set_title("Valeur fonciere par département en France en 2020 (en euros)", fontdict={'fontsize': '18', 'fontweight' : '3'})
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        data = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", sep='|', dtype=dtype)
        data["Type local"] = data["Type local"].astype(str)
        data = data[~data["Type local"].str.startswith(("COM", "CT"))]
        if not pd.api.types.is_numeric_dtype(data["Valeur fonciere"]):
            print("La colonne Valeur fonciere ne contient pas de données numériques.")
            return
        data_agg = data.groupby("Code departement")["Valeur fonciere"].sum().reset_index()
        departements = gpd.read_file("https://github.com/gregoiredavid/france-geojson/raw/master/departements.geojson")
        departements = departements.merge(data_agg, left_on="code", right_on="Code departement")
        fig, ax = plt.subplots(figsize=(10, 5))
        departements.plot(column="Valeur fonciere", cmap="YlGnBu", linewidth=0.8, edgecolor='0.8', ax=ax, legend=True)
        ax.axis('off')
        ax.set_title("Valeur fonciere par département en France en 2019 (en euros)", fontdict={'fontsize': '18', 'fontweight' : '3'})
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        data = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", sep='|', dtype=dtype)
        data["Type local"] = data["Type local"].astype(str)
        data = data[~data["Type local"].str.startswith(("COM", "CT"))]
        if not pd.api.types.is_numeric_dtype(data["Valeur fonciere"]):
            print("La colonne Valeur fonciere ne contient pas de données numériques.")
            return
        data_agg = data.groupby("Code departement")["Valeur fonciere"].sum().reset_index()
        departements = gpd.read_file("https://github.com/gregoiredavid/france-geojson/raw/master/departements.geojson")
        departements = departements.merge(data_agg, left_on="code", right_on="Code departement")
        fig, ax = plt.subplots(figsize=(10, 5))
        departements.plot(column="Valeur fonciere", cmap="YlGnBu", linewidth=0.8, edgecolor='0.8', ax=ax, legend=True)
        ax.axis('off')
        ax.set_title("Valeur fonciere par département en France en 2018 (en euros)", fontdict={'fontsize': '18', 'fontweight' : '3'})
        fig=plt.gcf()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template2.html', {'data': uri})

def index6(request):
    plt.clf()
    df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
    # Calculer le prix du m²
    prixM2 = df.loc[:, ['Code departement', 'Valeur fonciere', 'Surface terrain']]
    prixM2['Prix du m2'] = prixM2['Valeur fonciere'] / prixM2['Surface terrain']   
    # Regrouper par département et calculer la moyenne du prix du m²
    PrixM2Moy = prixM2.groupby('Code departement')['Prix du m2'].mean()
    PrixM2Moy = PrixM2Moy.reset_index()
    # Créer le graphique
    plt.figure(figsize=(12, 6))
    plt.bar(PrixM2Moy['Code departement'], PrixM2Moy['Prix du m2'])
    plt.xlabel('Département')
    plt.ylabel('Prix du m²')
    plt.title('Prix du m² par département en 2022 (en euros)')
    fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template3.html', {'data': uri})

def index7(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                     sep='|', dtype=dtype)
        # Calculer le prix du m²
        prixM2 = df.loc[:, ['Code departement', 'Valeur fonciere', 'Surface terrain']]
        prixM2['Prix du m2'] = prixM2['Valeur fonciere'] / prixM2['Surface terrain']   
        # Regrouper par département et calculer la moyenne du prix du m²
        PrixM2Moy = prixM2.groupby('Code departement')['Prix du m2'].mean()
        PrixM2Moy = PrixM2Moy.reset_index()
        # Créer le graphique
        plt.figure(figsize=(12, 6))
        plt.bar(PrixM2Moy['Code departement'], PrixM2Moy['Prix du m2'])
        plt.xlabel('Département')
        plt.ylabel('Prix du m²')
        plt.title('Prix du m² par département en 2022 (en euros)')
        fig=plt.gcf()
    
    if (request.GET['model']=="2021"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", 
                     sep='|', dtype=dtype)
        # Calculer le prix du m²
        prixM2 = df.loc[:, ['Code departement', 'Valeur fonciere', 'Surface terrain']]
        prixM2['Prix du m2'] = prixM2['Valeur fonciere'] / prixM2['Surface terrain']   
        # Regrouper par département et calculer la moyenne du prix du m²
        PrixM2Moy = prixM2.groupby('Code departement')['Prix du m2'].mean()
        PrixM2Moy = PrixM2Moy.reset_index()
        # Créer le graphique
        plt.figure(figsize=(12, 6))
        plt.bar(PrixM2Moy['Code departement'], PrixM2Moy['Prix du m2'])
        plt.xlabel('Département')
        plt.ylabel('Prix du m²')
        plt.title('Prix du m² par département en 2021 (en euros)')
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", 
                     sep='|', dtype=dtype)
        # Calculer le prix du m²
        prixM2 = df.loc[:, ['Code departement', 'Valeur fonciere', 'Surface terrain']]
        prixM2['Prix du m2'] = prixM2['Valeur fonciere'] / prixM2['Surface terrain']   
        # Regrouper par département et calculer la moyenne du prix du m²
        PrixM2Moy = prixM2.groupby('Code departement')['Prix du m2'].mean()
        PrixM2Moy = PrixM2Moy.reset_index()
        # Créer le graphique
        plt.figure(figsize=(12, 6))
        plt.bar(PrixM2Moy['Code departement'], PrixM2Moy['Prix du m2'])
        plt.xlabel('Département')
        plt.ylabel('Prix du m²')
        plt.title('Prix du m² par département en 2020 (en euros)')
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", 
                     sep='|', dtype=dtype)
        # Calculer le prix du m²
        prixM2 = df.loc[:, ['Code departement', 'Valeur fonciere', 'Surface terrain']]
        prixM2['Prix du m2'] = prixM2['Valeur fonciere'] / prixM2['Surface terrain']   
        # Regrouper par département et calculer la moyenne du prix du m²
        PrixM2Moy = prixM2.groupby('Code departement')['Prix du m2'].mean()
        PrixM2Moy = PrixM2Moy.reset_index()
        # Créer le graphique
        plt.figure(figsize=(12, 6))
        plt.bar(PrixM2Moy['Code departement'], PrixM2Moy['Prix du m2'])
        plt.xlabel('Département')
        plt.ylabel('Prix du m²')
        plt.title('Prix du m² par département en 2019 (en euros)')
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", 
                     sep='|', dtype=dtype)
        # Calculer le prix du m²
        prixM2 = df.loc[:, ['Code departement', 'Valeur fonciere', 'Surface terrain']]
        prixM2['Prix du m2'] = prixM2['Valeur fonciere'] / prixM2['Surface terrain']   
        # Regrouper par département et calculer la moyenne du prix du m²
        PrixM2Moy = prixM2.groupby('Code departement')['Prix du m2'].mean()
        PrixM2Moy = PrixM2Moy.reset_index()
        # Créer le graphique
        plt.figure(figsize=(12, 6))
        plt.bar(PrixM2Moy['Code departement'], PrixM2Moy['Prix du m2'])
        plt.xlabel('Département')
        plt.ylabel('Prix du m²')
        plt.title('Prix du m² par département en 2018 (en euros)')
        fig=plt.gcf()
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template3.html', {'data': uri})

def index8(request):
    plt.clf()
    df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
    # Extraction du mois à partir de la date de mutation
    df['Mois'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y').dt.month   
    # Groupement par mois et calcul du nombre de transactions
    df_transactions_par_mois = df.groupby('Mois').size().reset_index(name='Nombre de transactions')
    # Affichage de l'histogramme
    plt.figure(figsize=(10, 6))
    plt.bar(df_transactions_par_mois['Mois'], df_transactions_par_mois['Nombre de transactions'])
    plt.xlabel('Mois')
    plt.ylabel('Nombre de transactions')
    plt.title('Nombre de transactions par mois en 2022')
    plt.xticks(range(1, 13))
    fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template4.html', {'data': uri})

def index9(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
        # Extraction du mois à partir de la date de mutation
        df['Mois'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y').dt.month   
        # Groupement par mois et calcul du nombre de transactions
        df_transactions_par_mois = df.groupby('Mois').size().reset_index(name='Nombre de transactions')
        # Affichage de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(df_transactions_par_mois['Mois'], df_transactions_par_mois['Nombre de transactions'])
        plt.xlabel('Mois')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par mois en 2022')
        plt.xticks(range(1, 13))
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", 
                 sep='|', dtype=dtype)
        # Extraction du mois à partir de la date de mutation
        df['Mois'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y').dt.month   
        # Groupement par mois et calcul du nombre de transactions
        df_transactions_par_mois = df.groupby('Mois').size().reset_index(name='Nombre de transactions')
        # Affichage de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(df_transactions_par_mois['Mois'], df_transactions_par_mois['Nombre de transactions'])
        plt.xlabel('Mois')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par mois en 2021')
        plt.xticks(range(1, 13))
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", 
                 sep='|', dtype=dtype)
        # Extraction du mois à partir de la date de mutation
        df['Mois'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y').dt.month   
        # Groupement par mois et calcul du nombre de transactions
        df_transactions_par_mois = df.groupby('Mois').size().reset_index(name='Nombre de transactions')
        # Affichage de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(df_transactions_par_mois['Mois'], df_transactions_par_mois['Nombre de transactions'])
        plt.xlabel('Mois')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par mois en 2020')
        plt.xticks(range(1, 13))
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", 
                 sep='|', dtype=dtype)
        # Extraction du mois à partir de la date de mutation
        df['Mois'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y').dt.month   
        # Groupement par mois et calcul du nombre de transactions
        df_transactions_par_mois = df.groupby('Mois').size().reset_index(name='Nombre de transactions')
        # Affichage de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(df_transactions_par_mois['Mois'], df_transactions_par_mois['Nombre de transactions'])
        plt.xlabel('Mois')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par mois en 2019')
        plt.xticks(range(1, 13))
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", 
                 sep='|', dtype=dtype)
        # Extraction du mois à partir de la date de mutation
        df['Mois'] = pd.to_datetime(df['Date mutation'], format='%d/%m/%Y').dt.month   
        # Groupement par mois et calcul du nombre de transactions
        df_transactions_par_mois = df.groupby('Mois').size().reset_index(name='Nombre de transactions')
        # Affichage de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(df_transactions_par_mois['Mois'], df_transactions_par_mois['Nombre de transactions'])
        plt.xlabel('Mois')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par mois en 2018')
        plt.xticks(range(1, 13))
        fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template4.html', {'data': uri})

def index10(request):
    plt.clf()
    df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
    df['Prix_m2'] = df['Valeur fonciere'] / df['Surface terrain']
    df_grouped = df.groupby('Code departement')['Prix_m2'].mean().reset_index()
    url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
    france = gpd.read_file(url)
    merged = france.merge(df_grouped, left_on='code', right_on='Code departement')
    fig, ax = plt.subplots(figsize=(10, 10))
    merged.plot(column='Prix_m2', cmap='Blues', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True)
    ax.set_title('Prix du mètre carré par département en 2022 (en euros)')
    fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template5.html', {'data': uri})

def index11(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                     sep='|', dtype=dtype)
        df['Prix_m2'] = df['Valeur fonciere'] / df['Surface terrain']
        df_grouped = df.groupby('Code departement')['Prix_m2'].mean().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(df_grouped, left_on='code', right_on='Code departement')
        fig, ax = plt.subplots(figsize=(10, 10))
        merged.plot(column='Prix_m2', cmap='Blues', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True)
        ax.set_title('Prix du mètre carré par département en 2022 (en euros)')
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", 
                     sep='|', dtype=dtype)
        df['Prix_m2'] = df['Valeur fonciere'] / df['Surface terrain']
        df_grouped = df.groupby('Code departement')['Prix_m2'].mean().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(df_grouped, left_on='code', right_on='Code departement')
        fig, ax = plt.subplots(figsize=(10, 10))
        merged.plot(column='Prix_m2', cmap='Blues', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True)
        ax.set_title('Prix du mètre carré par département en 2021 (en euros)')
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", 
                     sep='|', dtype=dtype)
        df['Prix_m2'] = df['Valeur fonciere'] / df['Surface terrain']
        df_grouped = df.groupby('Code departement')['Prix_m2'].mean().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(df_grouped, left_on='code', right_on='Code departement')
        fig, ax = plt.subplots(figsize=(10, 10))
        merged.plot(column='Prix_m2', cmap='Blues', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True)
        ax.set_title('Prix du mètre carré par département en 2020 (en euros)')
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", 
                     sep='|', dtype=dtype)
        df['Prix_m2'] = df['Valeur fonciere'] / df['Surface terrain']
        df_grouped = df.groupby('Code departement')['Prix_m2'].mean().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(df_grouped, left_on='code', right_on='Code departement')
        fig, ax = plt.subplots(figsize=(10, 10))
        merged.plot(column='Prix_m2', cmap='Blues', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True)
        ax.set_title('Prix du mètre carré par département en 2019 (en euros)')
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", 
                     sep='|', dtype=dtype)
        df['Prix_m2'] = df['Valeur fonciere'] / df['Surface terrain']
        df_grouped = df.groupby('Code departement')['Prix_m2'].mean().reset_index()
        url = 'https://raw.githubusercontent.com/gregoiredavid/france-geojson/master/departements.geojson'
        france = gpd.read_file(url)
        merged = france.merge(df_grouped, left_on='code', right_on='Code departement')
        fig, ax = plt.subplots(figsize=(10, 10))
        merged.plot(column='Prix_m2', cmap='Blues', linewidth=0.8, ax=ax, edgecolor='0.8', legend=True)
        ax.set_title('Prix du mètre carré par département en 2018 (en euros)')
        fig=plt.gcf()        
    
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template5.html', {'data': uri})

def index12(request):
    plt.clf()
    df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
    # Conversion de la colonne 'Date mutation' en format de date
    df['Date mutation'] = pd.to_datetime(df['Date mutation'])
    # Extraction de la date et du nombre de transactions par jour
    transactions_par_jour = df.groupby(df['Date mutation'].dt.date).size()
    # Création de l'histogramme
    plt.figure(figsize=(10, 6))
    plt.bar(transactions_par_jour.index, transactions_par_jour.values)
    plt.xlabel('Date')
    plt.ylabel('Nombre de transactions')
    plt.title('Nombre de transactions par jour en 2022')
    plt.xticks(rotation=45)
    plt.tight_layout()
    fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template6.html', {'data': uri})

def index13(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
        # Conversion de la colonne 'Date mutation' en format de date
        df['Date mutation'] = pd.to_datetime(df['Date mutation'])
        # Extraction de la date et du nombre de transactions par jour
        transactions_par_jour = df.groupby(df['Date mutation'].dt.date).size()
        # Création de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(transactions_par_jour.index, transactions_par_jour.values)
        plt.xlabel('Date')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par jour en 2022')
        plt.xticks(rotation=45)
        plt.tight_layout()
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", 
                 sep='|', dtype=dtype)
        # Conversion de la colonne 'Date mutation' en format de date
        df['Date mutation'] = pd.to_datetime(df['Date mutation'])
        # Extraction de la date et du nombre de transactions par jour
        transactions_par_jour = df.groupby(df['Date mutation'].dt.date).size()
        # Création de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(transactions_par_jour.index, transactions_par_jour.values)
        plt.xlabel('Date')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par jour en 2021')
        plt.xticks(rotation=45)
        plt.tight_layout()
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", 
                 sep='|', dtype=dtype)
        # Conversion de la colonne 'Date mutation' en format de date
        df['Date mutation'] = pd.to_datetime(df['Date mutation'])
        # Extraction de la date et du nombre de transactions par jour
        transactions_par_jour = df.groupby(df['Date mutation'].dt.date).size()
        # Création de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(transactions_par_jour.index, transactions_par_jour.values)
        plt.xlabel('Date')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par jour en 2020')
        plt.xticks(rotation=45)
        plt.tight_layout()
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", 
                 sep='|', dtype=dtype)
        # Conversion de la colonne 'Date mutation' en format de date
        df['Date mutation'] = pd.to_datetime(df['Date mutation'])
        # Extraction de la date et du nombre de transactions par jour
        transactions_par_jour = df.groupby(df['Date mutation'].dt.date).size()
        # Création de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(transactions_par_jour.index, transactions_par_jour.values)
        plt.xlabel('Date')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par jour en 2019')
        plt.xticks(rotation=45)
        plt.tight_layout()
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", 
                 sep='|', dtype=dtype)
        # Conversion de la colonne 'Date mutation' en format de date
        df['Date mutation'] = pd.to_datetime(df['Date mutation'])
        # Extraction de la date et du nombre de transactions par jour
        transactions_par_jour = df.groupby(df['Date mutation'].dt.date).size()
        # Création de l'histogramme
        plt.figure(figsize=(10, 6))
        plt.bar(transactions_par_jour.index, transactions_par_jour.values)
        plt.xlabel('Date')
        plt.ylabel('Nombre de transactions')
        plt.title('Nombre de transactions par jour en 2018')
        plt.xticks(rotation=45)
        plt.tight_layout()
        fig=plt.gcf() 
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template6.html', {'data': uri})

def index14(request):
    plt.clf()
    df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
    DfTDate = df[['Date mutation', 'Nature mutation']]
    DfTDate[['J', 'M', 'A']] = DfTDate['Date mutation'].str.split('/', expand=True)
    DfTDate['M/J'] = DfTDate['M'].str.cat(DfTDate['J'], sep='/')
    DfTDate = DfTDate.drop(['A', 'J', 'M', 'Date mutation'], axis=1)
    DfTDateGrJ = DfTDate.groupby('M/J').count().reset_index()
    DfTDateGrJ.plot(x="M/J", y="Nature mutation", kind="area", figsize=(20, 10))
    plt.xlabel('Mois/Jour')
    plt.ylabel('Nombre de mutations')
    plt.title('Nombre de mutations par date en 2022')
    fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template7.html', {'data': uri})

def index15(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
        DfTDate = df[['Date mutation', 'Nature mutation']]
        DfTDate[['J', 'M', 'A']] = DfTDate['Date mutation'].str.split('/', expand=True)
        DfTDate['M/J'] = DfTDate['M'].str.cat(DfTDate['J'], sep='/')
        DfTDate = DfTDate.drop(['A', 'J', 'M', 'Date mutation'], axis=1)
        DfTDateGrJ = DfTDate.groupby('M/J').count().reset_index()
        DfTDateGrJ.plot(x="M/J", y="Nature mutation", kind="area", figsize=(20, 10))
        plt.xlabel('Mois/Jour')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par date en 2022')
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", 
                 sep='|', dtype=dtype)
        DfTDate = df[['Date mutation', 'Nature mutation']]
        DfTDate[['J', 'M', 'A']] = DfTDate['Date mutation'].str.split('/', expand=True)
        DfTDate['M/J'] = DfTDate['M'].str.cat(DfTDate['J'], sep='/')
        DfTDate = DfTDate.drop(['A', 'J', 'M', 'Date mutation'], axis=1)
        DfTDateGrJ = DfTDate.groupby('M/J').count().reset_index()
        DfTDateGrJ.plot(x="M/J", y="Nature mutation", kind="area", figsize=(20, 10))
        plt.xlabel('Mois/Jour')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par date en 2021')
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", 
                 sep='|', dtype=dtype)
        DfTDate = df[['Date mutation', 'Nature mutation']]
        DfTDate[['J', 'M', 'A']] = DfTDate['Date mutation'].str.split('/', expand=True)
        DfTDate['M/J'] = DfTDate['M'].str.cat(DfTDate['J'], sep='/')
        DfTDate = DfTDate.drop(['A', 'J', 'M', 'Date mutation'], axis=1)
        DfTDateGrJ = DfTDate.groupby('M/J').count().reset_index()
        DfTDateGrJ.plot(x="M/J", y="Nature mutation", kind="area", figsize=(20, 10))
        plt.xlabel('Mois/Jour')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par date en 2020')
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", 
                 sep='|', dtype=dtype)
        DfTDate = df[['Date mutation', 'Nature mutation']]
        DfTDate[['J', 'M', 'A']] = DfTDate['Date mutation'].str.split('/', expand=True)
        DfTDate['M/J'] = DfTDate['M'].str.cat(DfTDate['J'], sep='/')
        DfTDate = DfTDate.drop(['A', 'J', 'M', 'Date mutation'], axis=1)
        DfTDateGrJ = DfTDate.groupby('M/J').count().reset_index()
        DfTDateGrJ.plot(x="M/J", y="Nature mutation", kind="area", figsize=(20, 10))
        plt.xlabel('Mois/Jour')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par date en 2019')
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", 
                 sep='|', dtype=dtype)
        DfTDate = df[['Date mutation', 'Nature mutation']]
        DfTDate[['J', 'M', 'A']] = DfTDate['Date mutation'].str.split('/', expand=True)
        DfTDate['M/J'] = DfTDate['M'].str.cat(DfTDate['J'], sep='/')
        DfTDate = DfTDate.drop(['A', 'J', 'M', 'Date mutation'], axis=1)
        DfTDateGrJ = DfTDate.groupby('M/J').count().reset_index()
        DfTDateGrJ.plot(x="M/J", y="Nature mutation", kind="area", figsize=(20, 10))
        plt.xlabel('Mois/Jour')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par date en 2018')
        fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template7.html', {'data': uri})

def index16(request):
    plt.clf()
    df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
    DfTDateM = df[['Date mutation', 'Nature mutation']]
    DfTDateM[['J', 'M', 'A']] = DfTDateM['Date mutation'].str.split('/', expand=True)
    DfTDateM = DfTDateM.drop(['A', 'J', 'Date mutation'], axis=1)
    DfTDateGrM = DfTDateM.groupby('M').count().reset_index()
    DfTDateGrM.plot(x="M", y="Nature mutation", kind="bar")
    plt.xlabel('Mois')
    plt.ylabel('Nombre de mutations')
    plt.title('Nombre de mutations par mois en 2022')
    fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template8.html', {'data': uri})

def index17(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
        DfTDateM = df[['Date mutation', 'Nature mutation']]
        DfTDateM[['J', 'M', 'A']] = DfTDateM['Date mutation'].str.split('/', expand=True)
        DfTDateM = DfTDateM.drop(['A', 'J', 'Date mutation'], axis=1)
        DfTDateGrM = DfTDateM.groupby('M').count().reset_index()
        DfTDateGrM.plot(x="M", y="Nature mutation", kind="bar")
        plt.xlabel('Mois')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par mois en 2022')
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", 
                 sep='|', dtype=dtype)
        DfTDateM = df[['Date mutation', 'Nature mutation']]
        DfTDateM[['J', 'M', 'A']] = DfTDateM['Date mutation'].str.split('/', expand=True)
        DfTDateM = DfTDateM.drop(['A', 'J', 'Date mutation'], axis=1)
        DfTDateGrM = DfTDateM.groupby('M').count().reset_index()
        DfTDateGrM.plot(x="M", y="Nature mutation", kind="bar")
        plt.xlabel('Mois')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par mois en 2021')
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", 
                 sep='|', dtype=dtype)
        DfTDateM = df[['Date mutation', 'Nature mutation']]
        DfTDateM[['J', 'M', 'A']] = DfTDateM['Date mutation'].str.split('/', expand=True)
        DfTDateM = DfTDateM.drop(['A', 'J', 'Date mutation'], axis=1)
        DfTDateGrM = DfTDateM.groupby('M').count().reset_index()
        DfTDateGrM.plot(x="M", y="Nature mutation", kind="bar")
        plt.xlabel('Mois')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par mois en 2020')
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", 
                 sep='|', dtype=dtype)
        DfTDateM = df[['Date mutation', 'Nature mutation']]
        DfTDateM[['J', 'M', 'A']] = DfTDateM['Date mutation'].str.split('/', expand=True)
        DfTDateM = DfTDateM.drop(['A', 'J', 'Date mutation'], axis=1)
        DfTDateGrM = DfTDateM.groupby('M').count().reset_index()
        DfTDateGrM.plot(x="M", y="Nature mutation", kind="bar")
        plt.xlabel('Mois')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par mois en 2019')
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", 
                 sep='|', dtype=dtype)
        DfTDateM = df[['Date mutation', 'Nature mutation']]
        DfTDateM[['J', 'M', 'A']] = DfTDateM['Date mutation'].str.split('/', expand=True)
        DfTDateM = DfTDateM.drop(['A', 'J', 'Date mutation'], axis=1)
        DfTDateGrM = DfTDateM.groupby('M').count().reset_index()
        DfTDateGrM.plot(x="M", y="Nature mutation", kind="bar")
        plt.xlabel('Mois')
        plt.ylabel('Nombre de mutations')
        plt.title('Nombre de mutations par mois en 2018')
        fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template8.html', {'data': uri})

def index18(request):
    plt.clf()
    df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
    departement_counts = df['Code departement'].value_counts().head(10)
    departement_names = departement_counts.index
    counts = departement_counts.values
    plt.bar(departement_names, counts)
    plt.xlabel('Départements')
    plt.ylabel('Nombre de mutations')
    plt.title('Top 10 des départements avec le plus grand nombre de mutations en 2022')
    plt.xticks(rotation=45)
    fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template9.html', {'data': uri})

def index19(request):
    plt.clf()
    if (request.GET['model']=="2022"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2022.txt", 
                 sep='|', dtype=dtype)
        departement_counts = df['Code departement'].value_counts().head(10)
        departement_names = departement_counts.index
        counts = departement_counts.values
        plt.bar(departement_names, counts)
        plt.xlabel('Départements')
        plt.ylabel('Nombre de mutations')
        plt.title('Top 10 des départements avec le plus grand nombre de mutations en 2022')
        plt.xticks(rotation=45)
        fig=plt.gcf()
        
    if (request.GET['model']=="2021"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2021.txt", 
                 sep='|', dtype=dtype)
        departement_counts = df['Code departement'].value_counts().head(10)
        departement_names = departement_counts.index
        counts = departement_counts.values
        plt.bar(departement_names, counts)
        plt.xlabel('Départements')
        plt.ylabel('Nombre de mutations')
        plt.title('Top 10 des départements avec le plus grand nombre de mutations en 2021')
        plt.xticks(rotation=45)
        fig=plt.gcf()
        
    if (request.GET['model']=="2020"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2020.txt", 
                 sep='|', dtype=dtype)
        departement_counts = df['Code departement'].value_counts().head(10)
        departement_names = departement_counts.index
        counts = departement_counts.values
        plt.bar(departement_names, counts)
        plt.xlabel('Départements')
        plt.ylabel('Nombre de mutations')
        plt.title('Top 10 des départements avec le plus grand nombre de mutations en 2020')
        plt.xticks(rotation=45)
        fig=plt.gcf()
        
    if (request.GET['model']=="2019"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2019.txt", 
                 sep='|', dtype=dtype)
        departement_counts = df['Code departement'].value_counts().head(10)
        departement_names = departement_counts.index
        counts = departement_counts.values
        plt.bar(departement_names, counts)
        plt.xlabel('Départements')
        plt.ylabel('Nombre de mutations')
        plt.title('Top 10 des départements avec le plus grand nombre de mutations en 2019')
        plt.xticks(rotation=45)
        fig=plt.gcf()
        
    if (request.GET['model']=="2018"):
        df = pd.read_csv("C://Users//aches//Documents//ESILV//A3//Info//Python//tris2018.txt", 
                 sep='|', dtype=dtype)
        departement_counts = df['Code departement'].value_counts().head(10)
        departement_names = departement_counts.index
        counts = departement_counts.values
        plt.bar(departement_names, counts)
        plt.xlabel('Départements')
        plt.ylabel('Nombre de mutations')
        plt.title('Top 10 des départements avec le plus grand nombre de mutations en 2018')
        plt.xticks(rotation=45)
        fig=plt.gcf()
        
    buffer = io.BytesIO()
    fig.savefig(buffer, format='png')
    buffer.seek(0)
    string=base64.b64encode(buffer.read())
    uri=urllib.parse.quote(string)
    return render(request, 'template9.html', {'data': uri})

