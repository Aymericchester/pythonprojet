from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("apply_Model", views.index1, name="index"),
    path("page1", views.index2, name="index"),
    path("apply_Model2", views.index3, name="index"),
    path("page2", views.index4, name="index"),
    path("apply_Model3", views.index5, name="index"),
    path("page3", views.index6, name="index"),
    path("apply_Model4", views.index7, name="index"),
    path("page4", views.index8, name="index"),
    path("apply_Model5", views.index9, name="index"),
    path("page5", views.index10, name="index"),
    path("apply_Model6", views.index11, name="index"),
    path("page6", views.index12, name="index"),
    path("apply_Model7", views.index13, name="index"),
    path("page7", views.index14, name="index"),
    path("apply_Model8", views.index15, name="index"),
    path("page8", views.index16, name="index"),
    path("apply_Model9", views.index17, name="index"),
    path("page9", views.index18, name="index"),
    path("apply_Model10", views.index19, name="index"),
]